#!/usr/bin/env python
# coding: utf-8

# In[1]:


get_ipython().system(' pip install pymongo[srv]')


# In[5]:


import requests
import time
from pymongo import MongoClient


# In[18]:


while True:
    r = requests.get( "http://api.tvmaze.com/singlesearch/shows?q=westworld&embed=episodes")
    if r.status_code == 200:
        data = r.json()
        print(data)
        time.sleep(60)
    else:
        exit()


# In[20]:


client = MongoClient("mongodb+srv://project123:project123@cluster0.i0hxs.mongodb.net/sample_db?ssl=true&ssl_cert_reqs=CERT_NONE")
db = client.get_database('FinaProject_db')
records = db.Shows_info
while True:
    r = requests.get( "http://api.tvmaze.com/singlesearch/shows?q=westworld&embed=episodes")
    if r.status_code == 200:
        data = r.json()
        print(data)
        records.insert_one(data)
        time.sleep(60)
    else:
        exit()


# In[ ]:


import datetime as dt

def my_job():
    client = MongoClient("mongodb+srv://project123:project123@cluster0.i0hxs.mongodb.net/sample_db?ssl=true&ssl_cert_reqs=CERT_NONE")
    db = client.get_database('FinaProject_db')
    records = db.Shows_info
    while True:
        r = requests.get( "http://api.tvmaze.com/singlesearch/shows?q=westworld&embed=episodes")
        if r.status_code == 200:
            data = r.json()
            print(data)
            records.insert_one(data)
            time.sleep(60)
        else:
            exit()
nextDay = dt.datetime.now() + dt.timedelta(days=1)
dateString = nextDay.strftime('%d-%m-%Y') + " 01-00-00"
newDate = nextDay.strptime(dateString,'%d-%m-%Y %H-%M-%S')
delay = (newDate - dt.datetime.now()).total_seconds()
Timer(delay,my_job,()).start()


# In[ ]:




